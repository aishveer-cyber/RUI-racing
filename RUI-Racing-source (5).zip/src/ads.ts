/**
 * AdMob interstitials.
 *
 * Two placements: the first tap on the title screen, and the moment the player
 * confirms their racer (right before a race starts). Both go through one
 * function with a cooldown, so the two can never stack on top of each other.
 *
 * TEST IDS ARE ON. Google treats taps on your own live ads as invalid traffic
 * and will suspend the AdMob account for it. Leave `USE_TEST_ADS` true until
 * the app is live in Play Store, then flip it to false and rebuild.
 */
import { Capacitor } from '@capacitor/core';
import { AdMob } from '@capacitor-community/admob';

/** Flip to false only once the app is published. */
const USE_TEST_ADS = false;

/** Google's public test interstitial — always fills, never earns, never penalised. */
const TEST_INTERSTITIAL = 'ca-app-pub-3940256099942544/1033173712';

/** Live unit from your AdMob console (interstitial / mediation). */
const LIVE_INTERSTITIAL = 'ca-app-pub-1521646441091514/2313798914';

/** Live unit from your AdMob console (rewarded interstitial). */
export const LIVE_REWARDED_INTERSTITIAL = 'ca-app-pub-1521646441091514/4735501012';

const COOLDOWN_MS = 45_000;
const PREPARE_TIMEOUT_MS = 6_000;

let initialised = false;
let showing = false;
let lastShown = 0;

function withTimeout<T>(p: Promise<T>, ms: number): Promise<T | void> {
  return Promise.race([p, new Promise<void>((r) => setTimeout(r, ms))]);
}

export async function initAds(): Promise<void> {
  if (initialised || !Capacitor.isNativePlatform()) return;
  initialised = true;
  try {
    await AdMob.initialize({ initializeForTesting: USE_TEST_ADS });
  } catch (e) {
    console.warn('[ads] init failed', e);
  }
}

/**
 * Show one interstitial. Always resolves — a missing ad network, no fill, or a
 * hung prepare must never strand the caller, because one caller is the race
 * start. Returns true only if an ad actually went to screen.
 */
export async function showInterstitial(): Promise<boolean> {
  if (!Capacitor.isNativePlatform() || showing) return false;
  const now = Date.now();
  if (now - lastShown < COOLDOWN_MS) return false;
  showing = true;
  lastShown = now;
  let shown = false;
  try {
    await initAds();
    await withTimeout(
      AdMob.prepareInterstitial({ adId: USE_TEST_ADS ? TEST_INTERSTITIAL : LIVE_INTERSTITIAL }),
      PREPARE_TIMEOUT_MS,
    );
    await AdMob.showInterstitial();
    shown = true;
  } catch (e) {
    console.warn('[ads] show failed', e);
  } finally {
    showing = false;
  }
  return shown;
}

/** First tap on the title screen is the natural first impression slot. */
export function installFirstTapAd(): void {
  if (!Capacitor.isNativePlatform()) return;
  void initAds();
  window.addEventListener('pointerdown', () => { void showInterstitial(); }, { once: true });
}
