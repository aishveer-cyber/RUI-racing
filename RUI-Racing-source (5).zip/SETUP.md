# RUI Racing — Android setup

This repo builds a signed **APK** and **AAB** from GitHub Actions. Nothing is
built on your machine unless you want to.

## What was changed from the original

| Area | Change |
|---|---|
| App name | `Kart Royale` → **RUI Racing** everywhere: page title, PWA manifest, boot screen, title-screen logo, trackside hoardings, the "rotate your device" notice, the replay download filename |
| Package id | `com.ruiracing.app` (Android `applicationId` and `namespace`) |
| Icons | Generated launcher icons, adaptive-icon foreground, round icon and splash screens in the RUI gold-on-navy style |
| Orientation | Locked to `sensorLandscape` — the game is landscape-only and says so on screen |
| Signing | Release signing read from environment variables, never from a committed file |
| Versioning | `versionCode` = workflow run number, `versionName` = git tag |
| Build | Capacitor 7 Android wrapper, npm scripts, GitHub Actions workflow |

## Build it

### 1. Push this folder to your own GitHub repo

```bash
git init -b main
git add -A
git commit -m "RUI Racing"
git remote add origin https://github.com/<you>/rui-racing.git
git push -u origin main
```

### 2. Create a signing key (once, ever)

```bash
keytool -genkeypair -v -keystore release.keystore -alias rui \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass 'YOUR_PASSWORD' -keypass 'YOUR_PASSWORD' \
  -dname "CN=RUI Racing, O=RUI, C=IN"

base64 -w0 release.keystore > release.keystore.b64
```

Keep `release.keystore` backed up and out of the repo. If you lose it you can
never update the app on Play Store again — Android ties updates to the key.

### 3. Add four repo secrets

Settings → Secrets and variables → Actions:

| Secret | Value |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | contents of `release.keystore.b64` |
| `ANDROID_KEYSTORE_PASSWORD` | the store password |
| `ANDROID_KEY_ALIAS` | `rui` |
| `ANDROID_KEY_PASSWORD` | the key password (same as store if you used one) |

### 4. Run it

Push to `main`, or Actions → *Build RUI Racing APK & AAB* → Run workflow.
Download `RUI-Racing.apk` and `RUI-Racing.aab` from the run summary.
Push a tag (`git tag v1.0.0 && git push --tags`) and both files attach to a
GitHub release as well.

## Build locally (optional)

Needs Node 20+, JDK 21, and the Android SDK with platform 35.

```bash
npm ci
npm run build            # web bundle into dist/
npx cap sync android     # copy dist/ into the Android project
cd android && ./gradlew assembleDebug
```

`npm run android:apk` and `npm run android:aab` do the first three steps for you.

## Where the branding lives, if you rename again

- `index.html` — `<title>`, `apple-mobile-web-app-title`, boot screen mark
- `public/manifest.webmanifest` — `name`, `short_name`
- `src/ui/Menus.ts` — the title-screen SVG logo (`RUI` on the arc, `RACING` below)
- `src/world/Props.ts` — trackside sponsor boards
- `capacitor.config.json` — `appName`, `appId`
- `android/app/src/main/res/values/strings.xml` — Android label
- `android/app/build.gradle` — `applicationId`, `namespace`

## Licence

MIT. `LICENSE` keeps Ryan Campbell's original copyright notice — that is a
condition of the licence and must stay. You may rename, modify and sell this;
you may not relicense the original code as proprietary, and you should not
imply the original author endorses RUI Racing.
