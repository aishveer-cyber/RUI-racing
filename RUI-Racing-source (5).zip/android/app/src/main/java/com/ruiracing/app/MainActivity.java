package com.ruiracing.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
